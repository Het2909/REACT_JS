import React, { useState } from 'react'

function Counter() {
    const[count,setCount]=useState(0)

    function add()
    {
        setCount(count+1)
    }

    function sub()
    {
        setCount(count-1)
    }

    function res()
    {
        setCount(0)
    }

  return (
    <div>
      <h1>{count}</h1>
      <button onClick={add}><h1>+</h1></button>
      <button onClick={sub}><h1>-</h1></button>
      <button onClick={res}><h1>reset</h1></button>
    </div>
  )
}

export default Counter
