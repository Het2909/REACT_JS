import logo from './logo.svg';
import './App.css';
import Counter from './Counter';
import { useState } from 'react';

function App() {
  const[name,setName]=useState('')
  const[age,setAge]=useState('')
  const[loca,setLoca]=useState('')

  return (
    <div className="App">
      <Counter></Counter>

      <input type='text' placeholder='Enter your name...!' onChange={(e)=>{setName(e.target.value)}}></input>
      <input type='text' placeholder='Enter your age...!' onChange={(e)=>{setAge(e.target.value)}}></input>
      <input type='text' placeholder='Enter your location...!' onChange={(e)=>{setLoca(e.target.value)}}></input>
      <Usercard name={name} age={age} location={loca}></Usercard>
      {/* <button onClick={()=>{<Usercard name={name} age={age} location={loca}></Usercard>}}>Submit</button> */}
    </div>
  );
}

function Usercard({name,age,location}){
  return(
    <div style={{
      backgroundColor:"wheat",
      marginLeft:"830px",
      border: "1px solid #ddd",
      borderRadius: "10px",
      padding: "16px",
      maxWidth: "250px",
      boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
      margin: "10px",
      fontFamily: "Arial, sans-serif"
    }}>
      <h2 style={{ margin: "0 0 10px 0" }}>{name}</h2>
      <p><strong>Age:</strong> {age}</p>
      <p><strong>Location:</strong> {location}</p>
    </div>
  )
}

export default App;
