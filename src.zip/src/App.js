import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import WelcomeMessage from './Class';

function App() {
  const [name,setName]=useState('')
  return (
    <div className="App">
      <WelcomeMessage></WelcomeMessage>
      <input type='text' placeholder='Write your name...!' onChange={(e)=>{setName(e.target.value)}}></input>
      <Greeting name={name}></Greeting>
    </div>
  );
}

function Greeting({name})
{
  return(
    <h1>Hello,{name}</h1>
  )
}

export default App;
